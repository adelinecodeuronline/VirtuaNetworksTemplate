window.onload = function() {
//Sélection du burger sur mobile
let menuMobile = document.querySelector('#burger');
menuMobile.addEventListener('click', displayMenu);

//Sélection des "+" sur mobile (cartes services)
document.querySelectorAll('.cross').forEach(item => {
  item.addEventListener('click', displayCaption);
});

//Sélection des "+" hexa rouges sur mobile (solutions)
document.querySelectorAll('.plus').forEach(crossPlus => {
  crossPlus.addEventListener('click', captionHexa);
});

//Sélection des "+" hexa gris clairs sur mobile (solutions)
document.querySelectorAll('.plus-white').forEach(crossWhite => {
  crossWhite.addEventListener('click', captionHexaWhite);
});

}


//Fonction pour faire apparaître le menu sur mobile au "click" burger
function displayMenu() {
    let navDisplay = document.querySelector('nav');
    navDisplay.style.display = 'block';
}


/***************************************************/

//fonction affichage overlay des cards services
function displayCaption() {
    const bg_white = this.parentNode;
    bg_white.querySelector('.cross').style.display = 'none';
    bg_white.querySelector('.overlay').style.display = 'block';

    const card = bg_white.parentNode;
    card.querySelector('.presentation').style.display = 'none';

}

/***************************************************/

//hexa rouges onclick: affichage overlay
function captionHexa() {
  let captionsRed = document.querySelectorAll('.overlay-hexa');
  captionsRed.forEach(oneCaptionRed => {
    oneCaptionRed.classList.remove ('open');
  });

  document.querySelectorAll('.plus');
  let idRed = this.dataset.id;
  document.querySelector(`#${idRed}`).classList.add('open');
  
}

//hexa gris onclick: affichage overlay
function captionHexaWhite() {
  let captionsWhite = document.querySelectorAll('.overlay-hexaWhite');
  captionsWhite.forEach(oneCaptionWhite => {
    oneCaptionWhite.classList.remove ('open');
  });

  document.querySelectorAll('.plus-white');
  let id = this.dataset.id;
  document.querySelector(`#${id}`).classList.add('open');
}






//fermeture menu mobile à revoir
//menu on scroll
//fermeture des cards services et des hexagones


