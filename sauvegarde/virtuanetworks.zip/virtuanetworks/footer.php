
</div>
    <footer>
    <img class="wave2" src="<?php bloginfo('template_directory');?>./assets/img/wavebuble gauche.png" alt="transition">
        <img class="fond" src="<?php bloginfo('template_directory');?>./assets/img/fond footer.jpg" alt="fond du footer">

        <div>
            <h1 class="footer-title" class="titre-section">PARTENAIRES</h1>
            <div class="ligne-titre"></div>
        </div>

        <div class="icons-partenaires">
            <img class="partenaires" src="<?php bloginfo('template_directory');?>./assets/img/logos partenaires/CISCO-.png" alt="Logo">
            <img class="partenaires" src="<?php bloginfo('template_directory');?>./assets/img/logos partenaires/Dell-Tech.png" alt="Logo">
            <img class="partenaires" src="<?php bloginfo('template_directory');?>./assets/img/logos partenaires/Fortinet.png" alt="Logo">
            <img class="partenaires" src="<?php bloginfo('template_directory');?>./assets/img/logos partenaires/Google.png" alt="Logo">
            <img class="partenaires" src="<?php bloginfo('template_directory');?>./assets/img/logos partenaires/HP.png" alt="Logo">
            <img class="partenaires" src="<?php bloginfo('template_directory');?>./assets/img/logos partenaires/VEEAM.png" alt="Logo">
            <img class="partenaires" src="<?php bloginfo('template_directory');?>./assets/img/logos partenaires/vmware.png" alt="Logo">
        </div>

        <div class="footer-link">
            <div class="reseaux">
                <p>Nous suivre</p>

                <div class="icon-reseaux">
                <a href="#"><img class="twi" src="<?php bloginfo('template_directory');?>./assets/img/twitter.png" alt="logo twitter"></a>
                <a href="#"><img class="linkedin" src="<?php bloginfo('template_directory');?>./assets/img/linkedin.png" alt ="linkedin"></a>
                </div>
            </div>
            
            <div  class="legaux">
                <a href="#">Mentions Légales</a>
                <a href="http://localhost/Virtua/cgv">CGV</a>
            </div>
            
        </div>
    </footer>
    <?php wp_footer(); ?>
</body>
</html>