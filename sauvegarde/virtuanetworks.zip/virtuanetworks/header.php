<?php $header = get_field('header');?> <!--Récupère les valeurs de champs du module ACF-->

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
    <title>Datacenter en Bourgogne Franche-Comté | Virtua Networks</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Raleway:wght@200;400;500;600;700&display=swap" rel="stylesheet">


    <?php wp_head() ?>
</head>
<body>

<header class="container"><!--Début Header-->
       
        <div id="figure-header">
            
            <div id="flex-triangles">
                <div id="polygon-header"><!--Grande figure grise-->

                    <img id="logo" src="<?php bloginfo('template_directory');?>./assets/img/logo.svg" alt="logo">
                    <img id="burger" src="<?php bloginfo('template_directory');?>./assets/img/burger.svg" alt="Burger menu"><!--Menu smartphone-->
                    <nav>
                        <div><!--Menu apparent web-->
                            <p>Coordonnées +33(0)1 86 95 94 95</p>
                            <p>info@virtuanetworks.com</p>
                        </div>

                        <ul>
                            <li><a href="#section2">Conseils et prestations</a></li>
                            <li><a href="#section3">Solutions</a></li>
                            <li><a href="#">Nos datacenters</a></li>
                            <li><a href="#">Références</a></li>
                            <li><a href="#">Contact</a></li>   
                        </ul>
                    </nav>

                    <h1>
                    <?php echo $header['slogan'];?><!--Affiche l'une des valeurs de champs ACF-->
                    </h1>
                <div>
                <p id="article-header">
                    <!--Sauvegarde de données, ou cloud, nous sommes spécialisés dans la virtualisation d’infrastructure, dans le design et la gestion d’architectures informatiques complexes. Nous sommes à même de répondre aux besoins de services des PME comme des grands comptes.-->
                    <?php echo $header['description'];?>
                </p>                 
            </div>
                </div>
                <div id="greyPolygon-header"></div><!--Petite figure grise-->
            </div>
        </div>
        <a href="#section3" class="btn" id="solution">Trouver une solution</a><!--CTA-->
        <img id="datas" src="<?php bloginfo('template_directory');?>./assets/img/illus-header-mobile.svg" alt="Sauvegarde de données">
        <div id="illus">
            <img src="<?php bloginfo('template_directory');?>./assets/img/cloud-header.svg" alt="cloud datas">
            <img src="<?php bloginfo('template_directory');?>./assets/img/Groupe-illus-header-web.svg" alt="transfert des données">
            <img src="<?php bloginfo('template_directory');?>./assets/img/local-header.svg" alt="datacenter local">
        </div>
   </header><!--Fin Header-->
