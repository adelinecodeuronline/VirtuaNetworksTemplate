<?php get_header(); ?>

<?php $services = get_field('services');?> <!--Récupère les valeurs de champs (services : cartes) du module ACF-->

   <main>
        <section class="container" id="cards"><!-- Début section cards services-->
            
                    <div class="card">
                       <div class="bg-white">
                            <h2><?php echo $services['titre_carte_1'];?></h2>
                            <img class="cross" src="<?php bloginfo('template_directory');?>./assets/img/cross.svg" alt="Informations">
                            <div class="overlay">
                                <p class="caption"><?php echo $services['description_survol_carte_1'];?></p>
                            </div>   
                       </div>              
                        <img src="<?php bloginfo('template_directory');?>./assets/img/sauvegarde.svg" alt="sauvegarde de données" class="presentation">
                    </div>

            
                <div class="card">
                    <div class="bg-white">
                        <h2><?php echo $services['titre_carte_2'];?></h2>
                        <img class="cross" src="<?php bloginfo('template_directory');?>./assets/img/cross.svg" alt="Informations">
                        <div class="overlay">
                            <p class="caption"><?php echo $services['description_survol_carte_2'];?></p>
                        </div>
                    </div>
                    <img src="<?php bloginfo('template_directory');?>./assets/img/hautdebit.svg" alt="connexion fibre" class="presentation">
                </div>

                <div class="card">
                    <div class="bg-white">
                        <h2><?php echo $services['titre_carte_3'];?></h2>
                        <img class="cross" src="<?php bloginfo('template_directory');?>./assets/img/cross.svg" alt="Informations">
                        <div class="overlay">
                            <p class="caption"><?php echo $services['description_survol_carte_3'];?></p>
                        </div>
                    </div>
                    <img src="<?php bloginfo('template_directory');?>./assets/img/hebergement_cloud.svg" alt="connexion fibre" class="presentation">
                </div>
            
        </section><!-- Fin section cards services-->
    <img class="wave" id="wave-conseil" src="<?php bloginfo('template_directory');?>./assets/img/wave-new.svg" alt="wave">

    <?php $conseil = get_field('conseil');?> <!--Récupère les valeurs de champs (conseil et prestations) du module ACF-->
    <!--Début section conseil et prestations -->
    <section id="section2">
        <h1 class="titre-section">conseil et prestations</h1>
        <div class="ligne-titre"></div>
        <div id="figures-conseil">     
            <div id="figure-gauche">
                <p><?php echo $conseil['partie_droite'];?></p>
            </div>
            <div id="figure-droite">
                <p><?php echo $conseil['partie_gauche'];?></p>
            </div>
        </div>  
        <img src="<?php bloginfo('template_directory');?>./assets/img/conseil-section2.svg" alt="conseil">
    </section><!--Fin section conseil et prestations -->

<!--Début section solutions -->
<?php $solutions = get_field('solutions');?> <!--Récupère les valeurs de champs (solutions) du module ACF-->
    <section id="section3">
        <h1 class="titre-section" id="solutions">solutions</h1>
        <div class="ligne-titre" id="ligne-solution"></div>
        <img class="photo-cover" id="photo-solutions" src="<?php bloginfo('template_directory');?>./assets/img/Conseil.jpg" alt="solutions datacenter">
        <img class="wave" id="wave-solutions" src="<?php bloginfo('template_directory');?>./assets/img/wave-new.svg" alt="wave">

        <div id="scroll-hexa"><!--Swipe version mobile-->
            <ul class="col-1">
                <div class="container-overlay-hexa"><!--hexa 1-->
                    <li><div class="hexa"><h2 class="titre-hexa">| réseaux interconnexions</h2><img class="img-hexa" src="<?php bloginfo('template_directory');?>./assets/img/vnfibre.svg" alt="vnfibre"><p class="service-hexa">Vn Fibre |</p><img class="plus" data-id="hexa1" src="<?php bloginfo('template_directory');?>./assets/img/cross-solutions.svg" alt="Informations"></div></li>
                    <div class="overlay-hexa" id="hexa1">
                        <p class="caption-hexa"><?php echo $solutions['description_interconnexions'];?><span></span>
                        <span></span>
                        <span class="titre-overlay">Vn Fibre |</span>
                        </p>
                    </div>
                </div><!--hexa 1-->
                
                <div class="container-overlay-hexaWhite"><!--hexa 2-->
                    <li><div class="hexa-white"><h2 class="titre-hexa-white">| technologie airmax</h2><img class="img-hexa" src="<?php bloginfo('template_directory');?>./assets/img/vnair.svg" alt="vnair"><p class="service-hexa-white">Vn Air |</p><img class="plus-white" data-id="hexa2" src="<?php bloginfo('template_directory');?>./assets/img/cross.svg" alt="Informations"></div></li>
                    <div class="overlay-hexaWhite" id="hexa2">
                        <p class="caption-hexaWhite"><?php echo $solutions['description_airmax'];?><span></span>
                        <span></span>
                        <span class="titre-overlayWhite">Vn Air |</span>
                        </p>
                    </div>
                </div><!--hexa 2-->
                
                <div class="container-overlay-hexaWhite"><!--hexa 3-->
                    <li><div class="hexa-white"><h2 class="titre-hexa-white">| accés haut débit</h2><img class="img-hexa" src="<?php bloginfo('template_directory');?>./assets/img/vnaccess.svg" alt="vnaccess"><p class="service-hexa-white">Vn Access |</p><img class="plus-white" data-id="hexa3" src="<?php bloginfo('template_directory');?>./assets/img/cross.svg" alt="Informations"></div></li>
                    <div class="overlay-hexaWhite" id="hexa3">
                        <p class="caption-hexaWhite"><?php echo $solutions['description_haut_debit'];?><span></span>
                        <span></span>
                        <span class="titre-overlayWhite">Vn Access |</span>
                        </p>
                    </div>
                </div><!--hexa 3-->
            </ul>

            <ul class="col-2">
                <div class="container-overlay-hexa"><!--hexa 4-->
                    <li><div class="hexa"><h2 class="titre-hexa">| sauvegarde des données</h2><img class="img-hexa" src="<?php bloginfo('template_directory');?>./assets/img/vnbackup.svg" alt="vnbackup"><p class="service-hexa">Vn Backup |</p><img class="plus" data-id="hexa4" src="<?php bloginfo('template_directory');?>./assets/img/cross-solutions.svg" alt="Informations"></div></li>
                    <div class="overlay-hexa" id="hexa4">
                        <p class="caption-hexa"><?php echo $solutions['description_donnees'];?><span></span>
                        <span></span>
                        <span class="titre-overlay">Vn Back up |</span>
                        </p>
                    </div>
                </div><!--hexa 4-->
                
                <div class="container-overlay-hexaWhite"><!--hexa 5-->
                    <li><div class="hexa-white"><h2 class="titre-hexa-white">| superviser</h2><img class="img-hexa" src="<?php bloginfo('template_directory');?>./assets/img/vnwatch.svg" alt="vnwatch"><p class="service-hexa-white">Vn Watch |</p><img class="plus-white" data-id="hexa5" src="<?php bloginfo('template_directory');?>./assets/img/cross.svg" alt="Informations"></div></li>
                    <div class="overlay-hexaWhite" id="hexa5">
                        <p class="caption-hexaWhite"><?php echo $solutions['description_superviser'];?><span></span>
                        <span></span>
                        <span class="titre-overlayWhite">Vn Watch |</span>
                        </p>
                    </div>
                </div><!--hexa 5-->
                
                <div class="container-overlay-hexaWhite"><!--hexa 6-->
                    <li><div class="hexa-white"><h2 class="titre-hexa-white">| sécuriser</h2><img class="img-hexa" src="<?php bloginfo('template_directory');?>./assets/img/vnrescue.svg" alt="vnrescue"><p class="service-hexa-white">Vn Rescue |</p><img class="plus-white" data-id="hexa6" src="<?php bloginfo('template_directory');?>./assets/img/cross.svg" alt="Informations"></div></li>
                    <div class="overlay-hexaWhite" id="hexa6">
                        <p class="caption-hexaWhite"><?php echo $solutions['description_securiser'];?><span></span>
                        <span></span>
                        <span class="titre-overlayWhite">Vn Rescue |</span>
                        </p>
                    </div>
                </div><!--hexa 6-->
            </ul>

            <ul class="col-3">
            <div class="container-overlay-hexaWhite"><!--hexa 7-->
                <li><div class="hexa-white"><h2 class="titre-hexa-white">| héberger</h2><img class="img-hexa" src="<?php bloginfo('template_directory');?>./assets/img/vnsaas.svg" alt="vnsaas"><p class="service-hexa-white">Vn Saas |</p><img class="plus-white" data-id="hexa7" src="<?php bloginfo('template_directory');?>./assets/img/cross.svg" alt="Informations"></div></li>
                <div class="overlay-hexaWhite" id="hexa7">
                    <p class="caption-hexaWhite"><?php echo $solutions['description_heberger'];?><span></span>
                    <span></span>
                    <span class="titre-overlayWhite">Vn Saas |</span>
                    </p>
                </div>
            </div><!--hexa 7-->   
                
            <div class="container-overlay-hexaWhite"><!--hexa 8-->
                <li><div class="hexa-white"><h2 class="titre-hexa-white">| pack cloud</h2><img class="img-hexa" src="<?php bloginfo('template_directory');?>./assets/img/vncloud.svg" alt="vncloud"><p class="service-hexa-white">Vn Cloud |</p><img class="plus-white" data-id="hexa8" src="<?php bloginfo('template_directory');?>./assets/img/cross.svg" alt="Informations"></div></li>
                <div class="overlay-hexaWhite" id="hexa8">
                    <p class="caption-hexaWhite"><?php echo $solutions['description_pack_cloud'];?><span></span>
                    <span></span>
                    <span class="titre-overlayWhite">Vn Cloud |</span>
                    </p>
                </div>
            </div><!--hexa 8-->
             
            <div class="container-overlay-hexa"><!--hexa 9-->
                <li><div class="hexa"><h2 class="titre-hexa">| hébergement & cloud</h2><img class="img-hexa" src="<?php bloginfo('template_directory');?>./assets/img/vnlass.svg" alt="vnlass"><p class="service-hexa">Vn Lass |</p><img class="plus" data-id="hexa9" src="<?php bloginfo('template_directory');?>./assets/img/cross-solutions.svg" alt="Informations"></div></li>
                <div class="overlay-hexa" id="hexa9">
                    <p class="caption-hexa"><?php echo $solutions['description_hebergement_et_cloud'];?><span></span>
                    <span></span>
                    <span class="titre-overlay">Vn Laas |</span>
                    </p>
                </div>
            </div><!--hexa 9-->
            </ul>
        </div>
            
    </section><!--Fin section solutions -->

    <!-- section data center -->
    <?php $datacenters = get_field('nos_datacenters');?> <!--Récupère les valeurs de champs (Nos datacenters) du module ACF-->
    <section class="container" id="datacenter">
            <div>
                <h1 class="titre-section">NOS DATACENTERS</h1>
                <div class="ligne-titre"></div>
            </div>

            <div class="flex-triangles2">
                <div class="figure-header2" id="polygon-header2"></div>
                <div id="greyPolygon-header2"></div>
            </div>

            <div class="intro-datacenter">
                <div class="verticale"></div>
                <p><?php echo $datacenters['description_datacenters'];?></p>
            </div>
             
            <div class="texte-datacenter">
                <div>
                <img class="equinix" src="<?php bloginfo('template_directory');?>./assets/img/datacenter auxerre.jpg" alt="Datacenter St Denis"> 
                <h3><span class="data-red">Equinix | </span>Saint-Denis</h3>
                <p><?php echo $datacenters['description_equinix'];?></p>
                </div>
            
                <div>
                    <img class="virtua" src="<?php bloginfo('template_directory');?>./assets/img/datacenter st denis.jpg" alt="Datacenter Auxerre">
                    <h3><span class="data-red">Virtua Center | </span>Auxerre</h3>
                    <p><?php echo $datacenters['description_virtuacenter'];?></p>
                </div>
            </div>

        </section>


        <!-- section références -->
        <section class="container2">
            <div>
                <h1 id="ref" class="titre-section">NOS REFERENCES</h1>
                <div class="ligne-titre"></div>
            </div>

            <div class="icons-references">
                <img class="references" src="<?php bloginfo('template_directory');?>./assets/img/logos references/AfriqueTelecom_Logo_positif.png" alt="Logo">
                <img class="references" src="<?php bloginfo('template_directory');?>./assets/img/logos references/CCI_Yonne.png" alt="Logo">
                <img class="references" src="<?php bloginfo('template_directory');?>./assets/img/logos references/FDJ.png" alt="Logo">
                <img class="references" src="<?php bloginfo('template_directory');?>./assets/img/logos references/habiteo-logo-color-white.png" alt="Logo">
                <img class="references" src="<?php bloginfo('template_directory');?>./assets/img/logos references/La_Chaine_Meteo.png" alt="Logo">
                <img class="references" src="<?php bloginfo('template_directory');?>./assets/img/logos references/ldlc.png" alt="Logo">
                <img class="references" src="<?php bloginfo('template_directory');?>./assets/img/logos references/logo-invoxis.png" alt="Logo">
                <img class="references" src="<?php bloginfo('template_directory');?>./assets/img/logos references/LOGO-OTSI.png" alt="Logo">
                <img class="references" src="<?php bloginfo('template_directory');?>./assets/img/logos references/logo-ymagis.png" alt="Logo">
                <img class="references" src="<?php bloginfo('template_directory');?>./assets/img/logos references/logo1.png" alt="Logo">
                <img class="references" src="<?php bloginfo('template_directory');?>./assets/img/logos references/msimond.png" alt="Logo">
                <img class="references" src="<?php bloginfo('template_directory');?>./assets/img/logos references/pagesjaunes-2.png" alt="Logo">
                <img class="references" src="<?php bloginfo('template_directory');?>./assets/img/logos references/Plastic_Omnium-2.png" alt="Logo">
                <img class="references" src="<?php bloginfo('template_directory');?>./assets/img/logos references/RAMSAY-1.png" alt="Logo">
                <img class="references" src="<?php bloginfo('template_directory');?>./assets/img/logos references/RFF.png" alt="Logo">
            </div>
        </section>


        <section class="contact">
            <div>
                <h1 class="titre-section">CONTACT</h1>
                <div class="ligne-titre"></div>
            </div>

            <div class="background-form">
                <form>
                    <div class="nom-prenom">
                        <div class="nom">
                            <label for="nom">Nom</label>
                            <input type="text" id="nom">
                        </div>

                        <div class="prenom">
                            <label for="prénom">Prénom</label>
                            <input type="text" id="prenom">
                        </div>
                    </div>

                    <div class="email">
                        <label for="email">E-mail</label>
                        <input type="email" id="email">
                    </div>

                    <div class="message">
                        <label for="msg">Message</label>
                        <textarea name="msg" id="message" rows="10" cols="50"></textarea>
                    </div>
            </div>
                    <div class="div-btn">
                        <a href="#" class="btn-envoyer">ENVOYER</a>
                    </div>
                </form>

            <div class="container" id="coordonnees">
                <p class="number">+33(0)1 86 95 94 95</p>
                <p class="mail-address">info@virtua-networks.com</p>
                <p class="address">24 rue des Champoulains 89000 Auxerre</p>
            </div>
        </section>
   </main>

   <?php get_footer(); ?>
