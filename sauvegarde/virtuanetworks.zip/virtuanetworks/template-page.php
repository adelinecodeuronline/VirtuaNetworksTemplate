<?php
/*
Template Name: Virtua Networks
Template Post Type: post, page
*/
?>
<?php get_header(); ?>
<?php $cgv = get_field('contenu_cgv'); ?>
<p id="cgv-contenu"><?php echo $cgv['contenu_cgv'];?></p>
<?php get_footer(); ?>