window.onload = function() {
//Sélection du burger sur mobile
let menuMobile = document.querySelector('#burger');
menuMobile.addEventListener('click', displayMenu);

//cards onclick: affichage overlay
let cross = document.querySelector('.cross');
cross.addEventListener('click', displayCaption);

//hexa onclick : affichage overlay
let crossHexa = document.querySelector('.cross.solutions');
crossHexa.addEventListener('click', captionHexa);

let crossHexaWhite = document.querySelector('.cross.solutions.white');
crossHexaWhite.addEventListener('click', captionHexaWhite);
}

//Fonction pour faire apparaître le menu sur mobile au "click" burger
function displayMenu() {
    let navDisplay = document.querySelector('nav');
    navDisplay.style.display = 'block';
}

window.onclick = function () {
    let navDisplay = document.querySelector('nav');
    if (!event.target.matches('#burger')) {
      navDisplay.style.display = 'none';
    }
  }

//cards onclick: affichage overlay
function displayCaption() {
  let overlay = document.querySelector('.overlay');
  overlay.style.display = 'block';
  
}
// fermeture de l'overlay cards
window.onclick = function () {
  let overlay = document.querySelector('.overlay');
   if (!event.target.matches('.cross')) {
    overlay.style.display = 'none';
    
  }
}

//hexa onclick: affichage overlay
function captionHexa() {
  let overlayHexa = document.querySelector('.overlay-hexa');
   overlayHexa.style.display = 'block';
    
}
// fermeture de l'overlay hexa
window.onclick = function () {
  let overlayHexa = document.querySelector('.overlay-hexa');
   if (!event.target.matches('.cross.solutions')) {
    overlayHexa.style.display = 'none';
        
  }
}

function captionHexaWhite() {
  let overlayHexaWhite = document.querySelector('.overlay-hexaWhite');
  overlayHexaWhite.style.display = 'block';
}

window.onclick = function() {
  let overlayHexaWhite = document.querySelector('.overlay-hexaWhite');
  if(!event.target.matches('.cross.solutions.white')) {
    overlayHexaWhite.style.display = 'none';
  }
}

//boucle autour des elements cross (cards + hexa)
//menu on croll
// target sections --> scroll
