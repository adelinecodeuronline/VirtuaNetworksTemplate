
<div id="footer">
    <p>Virtua Networks | Copyright 2021</p>
</div>


</div>
    <footer>
    <!--html footer ici-->
    </footer>
    <?php wp_footer(); ?>
</body>
</html>