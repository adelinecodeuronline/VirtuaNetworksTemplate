<?php 
/* Chargement feuilles de style*/
function virtua_enqueue_assets() {
  
    /* theme's primary style.css file */
    wp_enqueue_style( 'virtua_main-css' , get_template_directory_uri() );
  
    /* template's primary css file */
    wp_enqueue_style( 'style_web' , get_template_directory_uri() . './style.css' );
    wp_enqueue_style( 'style_mobile' , get_template_directory_uri() . './style-mobile.css' );
    
    
  }
  add_action( 'wp_enqueue_scripts' , 'virtua_enqueue_assets' );


//Chargement script

function addjs() {
    wp_enqueue_style( 'virtua_main-js' , get_template_directory_uri() );
    wp_enqueue_script('script_virtua', get_template_directory_uri() . './assets/js/script.js');
    //wp_enqueue_script('script_virtua');
}
add_action( 'wp_enqueue_scripts' , 'addjs' );



