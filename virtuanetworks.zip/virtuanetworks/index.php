<?php get_header(); ?>


   <main>
        <section class="container" id="cards"><!-- Début section cards services-->
            
                    <div class="card">
                        <div class="container-overlay"></div>
                        <h1>Sauvegarder les
                        données
                        externalisées</h1>
                        <img class="cross" src="<?php bloginfo('template_directory');?>./assets/img/cross.svg" alt="Informations">                      
                        <img src="<?php bloginfo('template_directory');?>./assets/img/sauvegarde.svg" alt="sauvegarde de données">
                            <div class="overlay">
                                <p class="caption">La supervision et la sauvegarde
                                    des données constituent
                                    l’assurance-vie d’une entreprise.
                                    Nous vous proposons de gérer
                                    cette partie stratégique de votre
                                    système d’information avec notre
                                    gamme de services managés.
                                    Vous profitez ainsi d’une
                                    sauvegarde rapide et fiable de vos
                                    données, qui sont alors stockées
                                    dans des environnements sécurisés
                                    et maîtrisés.</p>
                            </div>
                        </div>
                    </div>

            
                <div class="card">
                    <div class="container-overlay">
                        <h1>Fournir un accès
                            Internet Haut Débit
                        </h1>
                        <img class="cross" src="<?php bloginfo('template_directory');?>./assets/img/cross.svg" alt="Informations">
                        <img src="<?php bloginfo('template_directory');?>./assets/img/hautdebit.svg" alt="connexion fibre">
                        <div class="overlay">
                            <p class="caption">Afin de vous connecter à
                                l’ensemble de vos applications de
                                manière optimale ainsi qu' à
                                Internet, nous vous proposons une
                                gamme de services réseaux.
                                Connectez-vous grâce aux lignes
                                xDSL, la Fibre Optique ou encore
                                avec la technologie hertzienne,
                                suivant vos besoins et votre
                                éligibilité.</p>
                        </div>
                    </div>
                </div>

            <div class="card">
                <div class="container-overlay">
                <h1>Héberger et
                    stocker sur le Cloud
                </h1>
                <img class="cross" src="<?php bloginfo('template_directory');?>./assets/img/cross.svg" alt="Informations">
                <img src="<?php bloginfo('template_directory');?>./assets/img/hebergement_cloud.svg" alt="stockage cloud">
                    <div class="overlay">
                        <p class="caption">Nous vous accompagnons dans le
                            développement de votre activité en
                            vous débarrassant des contraintes
                            liées à la gestion quotidienne de
                            l’IT.
                            Un hébergement et une offre cloud
                            complète, incluant l’ensemble de
                            services, simplifient et optimisent la
                            gestion de l’informatique pour les
                            entreprises ou les particuliers.</p>
                    </div>
                </div>
            </div>
        </section><!-- Fin section cards services-->
    <img class="wave" id="wave-conseil" src="<?php bloginfo('template_directory');?>./assets/img/wave-new.svg" alt="wave">

    <!--Début section conseil et prestations -->
    <section id="section2">
        <h1 class="titre-section">conseil et prestations</h1>
        <div class="ligne-titre"></div>
        <div id="figures-conseil">     
            <div id="figure-gauche">
                <p>Nos datacenters proposent différents services liés à la gestion SI :
                
                    - Délégation de compétences
                    
                    - Conseil en architecture
                    
                    - Etude et audit
                    
                    - Gestion et accompagnement de projets
                    
                    - Intégration d’infrastructures
                                
                    En nous appuyant sur les nouvelles technologies, nous permettons aux entreprises d’accroître leur rentabilité et d’améliorer leur efficacité.
                    
                    Nos solutions sont adaptées en fonction de votre métier et de vos objectifs.
                </p>
            </div>
            <div id="figure-droite">
                <p>Nous vous conseillons sur le design, la mise en place ou la migration d’infrastructures informatiques.

                    Spécialistes des architectures virtualisées, nos compétences couvrent l’ensemble des technologies liées à l’environnement Datacenter et donc à la virtualisation.
                    
                    Nous faisons évoluer votre système d’information ou améliorons l’existant.
                    
                    Nous transformons ou migrons le réseau de votre entreprise.</p>
            </div>
        </div>  
        <img src="<?php bloginfo('template_directory');?>./assets/img/conseil-section2.svg" alt="conseil">
    </section><!--Fin section conseil et prestations -->

<!--Début section solutions -->
    <section id="section3">
        <h1 class="titre-section" id="solutions">solutions</h1>
        <div class="ligne-titre" id="ligne-solution"></div>
        <img class="photo-cover" id="photo-solutions" src="<?php bloginfo('template_directory');?>./assets/img/Conseil.jpg" alt="solutions datacenter">
        <img class="wave" id="wave-solutions" src="<?php bloginfo('template_directory');?>./assets/img/wave-new.svg" alt="wave">

        <div id="scroll-hexa"><!--Swipe version mobile-->
            <div class="col-1">
                <div class="container-overlay-hexa">
                    <div class="hexa" id="hexa1"><h2 class="titre-hexa">| réseaux interconnexions</h2><img class="img-hexa" src="<?php bloginfo('template_directory');?>./assets/img/vnfibre.svg" alt="vnfibre"><p class="service-hexa">Vn Fibre |</p><img class="cross solutions" src="<?php bloginfo('template_directory');?>./assets/img/cross-solutions.svg" alt="Informations">
                        <div class="overlay-hexa">
                            <p class="caption-hexa">Pour des connexions fiables
                                plus performantes
                                composées de débits très
                                élevés et stables, nous vous
                                fourissons une connexion au réseau 
                                en Fibre Optique.

                                Vous bénéficiez ainsi d'une
                                vitesse d'accés haut débit,
                                tant au réseau Internet qu'à
                                vos applications hébergées
                                dans nos datacenters.
                                <span class="titre-overlay">Vn Fibre |</span>
                            </p>
                        </div>
                    </div>
                </div>

                <div class="container-overlay-hexaWhite">
                    <div class="hexa-white" id="hexa2"><h2 class="titre-hexa-white">| technologie airmax</h2><img class="img-hexa" src="<?php bloginfo('template_directory');?>./assets/img/vnair.svg" alt="vnair"><p class="service-hexa-white">Vn Air |</p><img class="cross solutions white" src="<?php bloginfo('template_directory');?>./assets/img/cross.svg" alt="Informations">
                        <div class="overlay-hexaWhite">
                            <p class="caption-hexaWhite">Afin de connecter entre eux
                                plusieurs sites sur un même
                                réseau, profitez d’un accès
                                Internet de qualité dans
                                une zone où l’accès aux
                                réseaux cuivrés est partiel ou 
                                défaillant. Ceci rendant les
                                connexions VPN ou le tirage
                                de câbles optionnels.
                                La technologie AirMax relie
                                vos sites dans une réseau 
                                MAN via une connexion Wi-Fi
                                Haut Débit à 5 GHz sécurisée.
                                <span class="titre-overlayWhite">Vn Air |</span>
                            </p>
                    </div>
                </div>

                <div class="container-overlay-hexaWhite">
                    <div class="hexa-white" id="hexa3"><h2 class="titre-hexa-white">| accés haut débit</h2><img class="img-hexa" src="<?php bloginfo('template_directory');?>./assets/img/vnaccess.svg" alt="vnaccess"><p class="service-hexa-white">Vn Access |</p><img class="cross solutions white" src="<?php bloginfo('template_directory');?>./assets/img/cross.svg" alt="Informations">
                        <div class="overlay-hexaWhite">
                            <p class="caption-hexaWhite">Mise en place de lignes
                                ADSL, SDSL et VDSL2 pour
                                les entreprises ayant besoin
                                de débits professionnels,
                                avec des liens facilement
                                intégrables et se basant sur
                                une technologie éprouvée.
                                <span class="titre-overlayWhite">Vn Access |</span>
                            </p>
                        </div>
                    </div>
                </div>
            </div><!--fin col 1-->

            <div class="col-2">
                <div class="container-overlay-hexa">
                    <div class="hexa" id="hexa4"><h2 class="titre-hexa">| sauvegarde des données</h2><img class="img-hexa" src="<?php bloginfo('template_directory');?>./assets/img/vnbackup.svg" alt="vnbackup"><p class="service-hexa">Vn Backup |</p><img class="cross solutions" src="<?php bloginfo('template_directory');?>./assets/img/cross-solutions.svg" alt="Informations">
                        <div class="overlay-hexa">
                            <p class="caption-hexa">Sauvegarde de vos serveurs
                                et de vos données sur une
                                infrastructure mutualisée ou 
                                privative.
                                Qu’elles se trouvent sur un
                                serveur physique ou une
                                machine virtuelle, nous
                                sauvegardons vos données
                                dans un environnement
                                sécurisé au sein de nos 
                                datacenters.
                                <span class="titre-overlay">Vn Backup |</span>
                            </p>
                        </div>
                    </div>
                </div>
                
                <div class="container-overlay-hexaWhite">
                    <div class="hexa-white" id="hexa5"><h2 class="titre-hexa-white">| superviser</h2><img class="img-hexa" src="<?php bloginfo('template_directory');?>./assets/img/vnwatch.svg" alt="vnwatch"><p class="service-hexa-white">Vn Watch |</p><img class="cross solutions white" src="<?php bloginfo('template_directory');?>./assets/img/cross.svg" alt="Informations">
                        <div class="overlay-hexaWhite">
                            <p class="caption-hexaWhite">Nous pouvons superviser vos
                                environnements et mettre en
                                place des alertes en fonction
                                de vos demandes, vous
                                permettant de réagir
                                rapidement en cas de
                                problèmes sur ceux-ci.
                                La garantie d'une surveillance
                                permanente sur vos données.
                                <span class="titre-overlayWhite">Vn Watch |</span>
                            </p>
                        </div>
                    </div>
                </div>
                
                <div class="container-overlay-hexaWhite">
                    <div class="hexa-white" id="hexa6"><h2 class="titre-hexa-white">| sécuriser</h2><img class="img-hexa" src="<?php bloginfo('template_directory');?>./assets/img/vnrescue.svg" alt="vnrescue"><p class="service-hexa-white">Vn Rescue |</p><img class="cross solutions white" src="<?php bloginfo('template_directory');?>./assets/img/cross.svg" alt="Informations">
                        <div class="overlay-hexaWhite">
                            <p class="caption-hexaWhite">Sécurisez l'ensemble de
                                votre infrastructure
                                informatique en la dupliquant
                                sur un second
                                environnement.
                                La copie des données est
                                hébergée dans un
                                environnement de secours,
                                au sein de nos datacenters.
                                La prise de relais s'effectue
                                ainsi, si nécessaire.
                                <span class="titre-overlayWhite">Vn Rescue |</span>
                            </p>
                        </div>
                    </div>
                </div>
            </div><!--fin col 2-->

            <div class="col-3">
                <div class="container-overlay-hexaWhite">
                    <div class="hexa-white" id="hexa7"><h2 class="titre-hexa-white">| héberger</h2><img class="img-hexa" src="<?php bloginfo('template_directory');?>./assets/img/vnsaas.svg" alt="vnsaas"><p class="service-hexa-white">Vn Saas |</p><img class="cross solutions" src="<?php bloginfo('template_directory');?>./assets/img/cross.svg" alt="Informations">
                        <div class="overlay-hexaWhite">
                            <p class="caption-hexaWhite">Pour héberger votre serveur
                                Web ou votre application
                                métier et afin de les rendre
                                disponibles, vous bénéficiez
                                d’un accès métier sur la
                                plateforme.
                                Nous nous occupons des
                                services managés, afin que
                                vous puissiez vous consacrer
                                à l’essentiel avec plus de
                                sérénité.
                                <span class="titre-overlayWhite">Vn SaaS |</span>
                            </p>
                        </div>
                    </div>
                </div>
                
                <div class="container-overlay-hexaWhite">
                    <div class="hexa-white" id="hexa8"><h2 class="titre-hexa-white">| pack cloud</h2><img class="img-hexa" src="<?php bloginfo('template_directory');?>./assets/img/vncloud.svg" alt="vncloud"><p class="service-hexa-white">Vn Cloud |</p><img class="cross solutions" src="<?php bloginfo('template_directory');?>./assets/img/cross.svg" alt="Informations">
                        <div class="overlay-hexaWhite">
                            <p class="caption-hexaWhite">L’offre cloud vous permet de
                                simplifier et d’optimiser la
                                gestion de l’informatique
                                dans votre entreprise.
                                En incluant la connexion
                                Internet, la messagerie, le
                                travail collaboratif,
                                l’application métier, le partage
                                et le stockage de données,
                                ou encore le site web, vous
                                profitez d'un panel complet.
                                <span class="titre-overlayWhite">Vn Cloud |</span>
                            </p>
                        </div>
                    </div>
                </div>
                
                <div class="container-overlay-hexa">
                    <div class="hexa" id="hexa9"><h2 class="titre-hexa">| hébergement & cloud</h2><img class="img-hexa" src="<?php bloginfo('template_directory');?>./assets/img/vnlass.svg" alt="vnlass"><p class="service-hexa">Vn Lass |</p><img class="cross solutions" src="<?php bloginfo('template_directory');?>./assets/img/cross-solutions.svg" alt="Informations">
                        <div class="overlay-hexa">
                            <p class="caption-hexa">Serveurs, espace de
                                stockage, réseaux dédiés,
                                etc : le tout est entièrement
                                accessible et gérable depuis
                                un accès réseau sécurisé.
                                Dans cette offre sur mesure,
                                vous pouvez choisir le
                                nombre de vCPU, la quantité
                                de RAM, le volume d’espace
                                de stockage, entre autres.
                                <span class="titre-overlay">Vn Lass |</span>
                            </p>
                        </div>
                    </div>
                </div>
            </div><!--fin col 3-->
        </div>
    </section><!--Fin section solutions -->
   </main>

   <?php get_footer(); ?>
